from .serializers import (educationSerializer, experienceSerializer, projectsSerializer,
               aboutSerializer, badgeSerializer, otherSerializer, extrasSerializer, contactSerializer)









