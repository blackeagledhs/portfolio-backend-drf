from django.shortcuts import render
from .views import (baseModelViewSet, educationViewSet, experienceViewSet, projectsViewSet,
                    aboutViewSet, badgeViewSet, otherViewSet, extraViewSet, contactViewSet, blank_page)




